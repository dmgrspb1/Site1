import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import Intro from '@/components/Intro';
import About from '@/components/About';
import Tours from '@/components/Tours';
import Gallery from '@/components/Gallery';
import Reviews from '@/components/Reviews';
import Contacts from '@/components/Contacts';
import Footer from '@/components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-ink-900 text-cream overflow-x-hidden">
      <Navbar />
      <main>
        <Hero />
        <Intro />
        <About />
        <Tours />
        <Gallery />
        <Reviews />
        <Contacts />
      </main>
      <Footer />
    </div>
  );
}

export default App;
