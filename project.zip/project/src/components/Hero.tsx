import { ChevronDown } from 'lucide-react';

export default function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background image with fallback gradient */}
      <div className="absolute inset-0 z-0">
        <div
          className="absolute inset-0 bg-cover bg-center animate-slow-zoom"
          style={{ backgroundImage: "url('my-image/photo1.jpg')" }}
        />
        {/* Gradient fallback shows through if image is missing */}
        <div className="absolute inset-0 jerusalem-hero-gradient -z-10" />
        {/* Dark overlay for readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-ink-900" />
        {/* Vignette */}
        <div className="absolute inset-0 shadow-[inset_0_0_200px_60px_rgba(0,0,0,0.7)]" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-3xl mx-auto pt-20">
        <p className="text-gold tracking-[0.3em] uppercase text-xs font-medium mb-6 opacity-0 animate-[fadeIn_1s_ease_forwards]">
          Лицензированный гид · Иерусалим
        </p>

        <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-medium text-white leading-[1.15] mb-6 opacity-0 animate-[fadeIn_1.2s_0.2s_ease_forwards]">
          Иерусалим, который вы
          <br className="hidden sm:block" />{' '}
          <span className="text-shimmer italic">не найдёте</span> в путеводителях
        </h1>

        <p className="text-lg sm:text-xl text-gold-light/90 font-light mb-10 max-w-xl mx-auto opacity-0 animate-[fadeIn_1.2s_0.4s_ease_forwards]">
          Авторские экскурсии с лицензированным гидом Оксаной Фельдман
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 opacity-0 animate-[fadeIn_1.2s_0.6s_ease_forwards]">
          <a
            href="#tours"
            className="px-8 py-3.5 bg-gold text-ink-900 font-semibold text-sm tracking-wide rounded-sm hover:bg-gold-bright transition-all duration-300 hover:shadow-[0_0_30px_rgba(201,162,75,0.4)]"
          >
            Посмотреть экскурсии
          </a>
          <a
            href="#contacts"
            className="px-8 py-3.5 border-2 border-gold text-gold-bright font-semibold text-sm tracking-wide rounded-sm hover:bg-gold hover:text-ink-900 transition-all duration-300"
          >
            Связаться со мной
          </a>
        </div>
      </div>

      {/* Scroll indicator */}
      <a
        href="#about"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 text-gold/60 hover:text-gold transition-colors animate-float"
        aria-label="Прокрутить вниз"
      >
        <ChevronDown size={28} />
      </a>

      <style>{`
        @keyframes fadeIn {
          to { opacity: 1; }
        }
      `}</style>
    </section>
  );
}
