import { useScrollReveal } from '@/hooks/useScrollReveal';
import { contactInfo } from '@/data/content';
import { Phone, Mail, Instagram, MessageCircle, Clock } from 'lucide-react';

export default function Contacts() {
  const { ref, isVisible } = useScrollReveal<HTMLDivElement>();

  return (
    <section
      id="contacts"
      className="relative py-24 px-6 border-t border-gold/20"
    >
      <div
        ref={ref}
        className={`relative max-w-2xl mx-auto reveal ${isVisible ? 'is-visible' : ''}`}
      >
        <h2 className="font-serif text-4xl text-center text-cream mb-2 font-semibold">
          Контакты
        </h2>
        <div className="w-14 h-px bg-gold mx-auto mb-6" />
        <p className="text-center text-cream/60 mb-14">
          Хотите забронировать экскурсию или задать вопрос? Буду рада пообщаться!
        </p>

        {/* Contact items */}
        <div className="space-y-4 mb-12">
          <a
            href={contactInfo.phoneHref}
            className="group flex items-center gap-4 p-5 bg-ink-800 border border-white/5 hover:border-gold/40 transition-all duration-300 rounded-sm"
          >
            <div className="w-12 h-12 flex items-center justify-center border border-gold/30 text-gold rounded-sm transition-all group-hover:border-gold group-hover:bg-gold/10">
              <Phone size={18} strokeWidth={1.5} />
            </div>
            <div>
              <p className="text-xs text-cream/40 uppercase tracking-wider mb-0.5">
                Телефон / WhatsApp
              </p>
              <p className="text-gold-bright text-lg font-serif">{contactInfo.phone}</p>
            </div>
          </a>

          <a
            href={`mailto:${contactInfo.email}`}
            className="group flex items-center gap-4 p-5 bg-ink-800 border border-white/5 hover:border-gold/40 transition-all duration-300 rounded-sm"
          >
            <div className="w-12 h-12 flex items-center justify-center border border-gold/30 text-gold rounded-sm transition-all group-hover:border-gold group-hover:bg-gold/10">
              <Mail size={18} strokeWidth={1.5} />
            </div>
            <div>
              <p className="text-xs text-cream/40 uppercase tracking-wider mb-0.5">
                Email
              </p>
              <p className="text-gold-bright text-lg font-serif">{contactInfo.email}</p>
            </div>
          </a>

          <a
            href={contactInfo.instagramHref}
            target="_blank"
            rel="noopener noreferrer"
            className="group flex items-center gap-4 p-5 bg-ink-800 border border-white/5 hover:border-gold/40 transition-all duration-300 rounded-sm"
          >
            <div className="w-12 h-12 flex items-center justify-center border border-gold/30 text-gold rounded-sm transition-all group-hover:border-gold group-hover:bg-gold/10">
              <Instagram size={18} strokeWidth={1.5} />
            </div>
            <div>
              <p className="text-xs text-cream/40 uppercase tracking-wider mb-0.5">
                Instagram
              </p>
              <p className="text-gold-bright text-lg font-serif">
                {contactInfo.instagram}
              </p>
            </div>
          </a>
        </div>

        {/* Hours */}
        <div className="flex items-start gap-4 p-5 bg-ink-800/50 border border-white/5 rounded-sm mb-10">
          <Clock size={20} className="text-gold mt-1 flex-shrink-0" strokeWidth={1.5} />
          <div className="text-sm text-cream/60 leading-relaxed">
            <p>
              <span className="text-gold-bright font-medium">Часы работы:</span>{' '}
              ежедневно, 8:00–20:00
            </p>
            <p className="text-cream/40">(кроме шаббата — по договорённости)</p>
            <p className="mt-2">
              <span className="text-gold-bright font-medium">Языки экскурсий:</span>{' '}
              русский, английский, иврит, украинский
            </p>
          </div>
        </div>

        <div className="text-center">
          <a
            href={contactInfo.whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-3.5 bg-gold text-ink-900 font-semibold text-sm tracking-wide rounded-sm hover:bg-gold-bright transition-all duration-300 hover:shadow-[0_0_30px_rgba(201,162,75,0.4)]"
          >
            <MessageCircle size={18} strokeWidth={2} />
            Написать в WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}
