import { useScrollReveal } from '@/hooks/useScrollReveal';
import { principles } from '@/data/content';
import { Sparkles } from 'lucide-react';

export default function About() {
  const { ref, isVisible } = useScrollReveal<HTMLDivElement>();

  return (
    <section id="about" className="relative py-24 px-6 overflow-hidden">
      {/* Decorative glow */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-gold/5 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />

      <div
        ref={ref}
        className={`relative max-w-5xl mx-auto reveal ${isVisible ? 'is-visible' : ''}`}
      >
        <h2 className="font-serif text-4xl text-center text-gold-bright mb-2 font-semibold">
          Обо мне
        </h2>
        <div className="w-14 h-px bg-gold mx-auto mb-16" />

        <div className="grid grid-cols-1 md:grid-cols-[300px_1fr] gap-12 items-start">
          {/* Photo with decorative frame */}
          <div className="relative group">
            <div className="absolute -inset-3 border border-gold/30 transition-all duration-500 group-hover:border-gold/60" />
            <img
              src="my-image/photo2.jpg"
              alt="Оксана Фельдман — гид в Иерусалиме"
              className="relative w-full rounded-sm grayscale-[20%] transition-all duration-700 group-hover:grayscale-0"
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = 'none';
                const parent = (e.target as HTMLImageElement).parentElement;
                if (parent) parent.classList.add('jerusalem-gradient', 'aspect-[3/4]');
              }}
            />
          </div>

          {/* Text */}
          <div>
            <p className="text-cream/70 leading-relaxed mb-5">
              Я — Оксана Фельдман, коренная иерусалимка, и, кажется, любовь к этому
              городу у меня в крови. Сколько себя помню, я исследовала переулки
              Старого города, расспрашивала старожилов, запоминала их истории — те
              самые, которых не найдёшь ни в одном путеводителе. Повзрослев, я поняла,
              что это не просто детское любопытство, а настоящее призвание. Так я
              стала лицензированным экскурсоводом.
            </p>
            <p className="text-cream/70 leading-relaxed mb-5">
              За восемь лет работы я провела сотни экскурсий и убедилась: Иерусалим
              невозможно узнать за один день и уж точно нельзя показать его по
              шаблону. Поэтому я предпочитаю нестандартные маршруты — от подземных
              туннелей у Стены Плача до малоизвестных смотровых площадок на Масличной
              горе. Мои гости часто говорят, что экскурсии со мной — это настоящее
              «путешествие во времени». И это лучший комплимент, который я могу
              услышать.
            </p>
            <p className="text-cream/70 leading-relaxed mb-5">
              Кроме того, я заядлый фотограф. Я знаю, где свет ложится на древние
              камни особенно красиво, и всегда подскажу вам лучший ракурс для снимка,
              который останется с вами на память об этом удивительном городе.
            </p>
            <p className="text-cream/70 leading-relaxed mb-8">
              Буду рада стать вашим проводником по Иерусалиму — городу, который я знаю
              и люблю всем сердцем.
            </p>

            {/* Principles */}
            <div className="border-t border-white/10 pt-8">
              <h3 className="font-serif text-xl text-gold mb-6 flex items-center gap-2">
                <Sparkles size={18} strokeWidth={1.5} />
                Мои принципы работы
              </h3>
              <ul className="space-y-3">
                {principles.map((principle, i) => (
                  <li
                    key={i}
                    className="flex items-start gap-3 text-cream/70 text-sm leading-relaxed pb-3 border-b border-white/5"
                  >
                    <span className="text-gold mt-1 text-xs">✦</span>
                    {principle}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div className="text-center mt-12">
          <a
            href="#tours"
            className="inline-block px-8 py-3.5 bg-gold text-ink-900 font-semibold text-sm tracking-wide rounded-sm hover:bg-gold-bright transition-all duration-300 hover:shadow-[0_0_30px_rgba(201,162,75,0.4)]"
          >
            Забронировать экскурсию
          </a>
        </div>
      </div>
    </section>
  );
}
