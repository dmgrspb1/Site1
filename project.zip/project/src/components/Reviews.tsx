import { useScrollReveal } from '@/hooks/useScrollReveal';
import { reviews, contactInfo } from '@/data/content';
import { Quote } from 'lucide-react';

export default function Reviews() {
  const { ref, isVisible } = useScrollReveal<HTMLDivElement>();

  return (
    <section id="reviews" className="relative py-24 px-6">
      <div
        ref={ref}
        className={`relative max-w-4xl mx-auto reveal ${isVisible ? 'is-visible' : ''}`}
      >
        <h2 className="font-serif text-4xl text-center text-gold-bright mb-2 font-semibold">
          Отзывы
        </h2>
        <div className="w-14 h-px bg-gold mx-auto mb-6" />
        <p className="text-center text-cream/60 italic mb-14 max-w-xl mx-auto">
          Мне доверяют самое ценное — время, проведённое в Иерусалиме. Вот что
          говорят мои гости.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {reviews.map((review, i) => (
            <div
              key={i}
              className={`relative bg-ink-800 border-l-2 border-gold p-7 pl-8 transition-all duration-500 hover:bg-ink-700 hover:border-l-4 reveal reveal-delay-${(i % 4) + 1} ${isVisible ? 'is-visible' : ''}`}
            >
              <Quote
                size={32}
                className="absolute top-4 right-4 text-gold/10"
                strokeWidth={1}
              />
              <p className="font-serif italic text-cream/80 leading-relaxed text-[0.95rem] relative z-10">
                {review.text}
              </p>
              <cite className="block mt-5 text-sm text-gold not-italic font-sans">
                — {review.author}
              </cite>
            </div>
          ))}
        </div>

        <div className="text-center mt-14">
          <p className="text-cream/60 italic mb-6">
            Хотите оставить отзыв? Напишите мне — буду рада вашим впечатлениям и
            фотографиям!
          </p>
          <a
            href={`mailto:${contactInfo.email}`}
            className="inline-block px-8 py-3.5 border-2 border-gold text-gold-bright font-semibold text-sm tracking-wide rounded-sm hover:bg-gold hover:text-ink-900 transition-all duration-300"
          >
            Оставить отзыв
          </a>
        </div>
      </div>
    </section>
  );
}
