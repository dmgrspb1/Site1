import { useScrollReveal } from '@/hooks/useScrollReveal';
import { features } from '@/data/content';

export default function Intro() {
  const { ref, isVisible } = useScrollReveal<HTMLDivElement>();

  return (
    <section className="relative py-24 px-6">
      {/* Subtle texture */}
      <div className="absolute inset-0 jerusalem-gradient opacity-30" />

      <div
        ref={ref}
        className={`relative max-w-5xl mx-auto reveal ${isVisible ? 'is-visible' : ''}`}
      >
        <p className="font-serif text-xl sm:text-2xl text-cream/90 text-center max-w-3xl mx-auto leading-relaxed mb-16 font-light italic">
          Здравствуйте! Меня зовут Оксана, и я живу в Иерусалиме всю жизнь. Этот
          город — не просто точка на карте, это мой дом, моя история и моя страсть.
          Уже более восьми лет я вожу гостей по улицам, переулкам и крышам Старого
          города, показывая им то, что обычно остаётся за кадром стандартных туров.
        </p>

        {/* Feature cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-white/5 border border-white/5">
          {features.map((feature, i) => {
            const Icon = feature.icon;
            return (
              <div
                key={feature.title}
                className={`group bg-ink-800 p-8 text-center transition-all duration-500 hover:bg-ink-700 reveal reveal-delay-${i + 1} ${isVisible ? 'is-visible' : ''}`}
              >
                <div className="inline-flex items-center justify-center w-14 h-14 mb-5 rounded-full border border-gold/30 text-gold transition-all duration-500 group-hover:border-gold group-hover:bg-gold/10 group-hover:scale-110">
                  <Icon size={24} strokeWidth={1.5} />
                </div>
                <h3 className="font-serif text-lg text-gold-bright mb-2 font-semibold">
                  {feature.title}
                </h3>
                <p className="text-sm text-cream/60 leading-relaxed">
                  {feature.text}
                </p>
              </div>
            );
          })}
        </div>

        {/* Quote preview */}
        <div className="mt-16 max-w-2xl mx-auto">
          <blockquote className="relative bg-ink-800/60 border-l-2 border-gold p-8 pl-10">
            <p className="font-serif italic text-lg text-cream/90 leading-relaxed">
              «Оксана показала нам Иерусалим, о котором мы даже не догадывались.
              Это было путешествие во времени!»
            </p>
            <cite className="block mt-4 text-sm text-gold not-italic font-sans">
              — Анна и Сергей, Москва
            </cite>
          </blockquote>
        </div>
      </div>
    </section>
  );
}
