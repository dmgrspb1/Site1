import { useScrollReveal } from '@/hooks/useScrollReveal';
import { galleryImages } from '@/data/content';

export default function Gallery() {
  const { ref, isVisible } = useScrollReveal<HTMLDivElement>();

  return (
    <section id="gallery" className="relative py-24 px-6 overflow-hidden">
      {/* Decorative glow */}
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-gold/5 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />

      <div
        ref={ref}
        className={`relative max-w-5xl mx-auto reveal ${isVisible ? 'is-visible' : ''}`}
      >
        <h2 className="font-serif text-4xl text-center text-gold-bright mb-2 font-semibold">
          Иерусалим в объективе
        </h2>
        <div className="w-14 h-px bg-gold mx-auto mb-14" />

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {galleryImages.map((img, i) => (
            <div
              key={i}
              className={`group relative overflow-hidden rounded-sm border border-gold/20 reveal reveal-delay-${i + 1} ${isVisible ? 'is-visible' : ''}`}
            >
              <div className="aspect-[4/3] jerusalem-gradient">
                <img
                  src={img.src}
                  alt={img.alt}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                />
              </div>
              {/* Overlay */}
              <div className="absolute inset-0 bg-ink-900/0 group-hover:bg-ink-900/30 transition-all duration-500 flex items-end p-4">
                <p className="text-cream text-sm font-serif italic opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-500">
                  {img.alt}
                </p>
              </div>
              {/* Corner accent */}
              <div className="absolute top-0 left-0 w-8 h-8 border-t border-l border-gold opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="absolute bottom-0 right-0 w-8 h-8 border-b border-r border-gold opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            </div>
          ))}
        </div>

        <p className="text-center text-cream/40 text-sm italic mt-10 font-serif">
          Каждый кадр — история, которую я с радостью расскажу вам на экскурсии.
        </p>
      </div>
    </section>
  );
}
