export default function Footer() {
  return (
    <footer className="bg-black border-t border-white/5 py-8 px-6">
      <div className="max-w-5xl mx-auto text-center">
        <p className="text-cream/30 text-sm font-serif tracking-wide">
          © 2025 Оксана Фельдман · Лицензированный гид в Иерусалиме
        </p>
      </div>
    </footer>
  );
}
