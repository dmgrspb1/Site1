import { useScrollReveal } from '@/hooks/useScrollReveal';
import { tours } from '@/data/content';

export default function Tours() {
  const { ref, isVisible } = useScrollReveal<HTMLDivElement>();

  return (
    <section id="tours" className="relative py-24 px-6">
      <div
        ref={ref}
        className={`relative max-w-5xl mx-auto reveal ${isVisible ? 'is-visible' : ''}`}
      >
        <h2 className="font-serif text-4xl text-center text-gold-bright mb-2 font-semibold">
          Экскурсии
        </h2>
        <div className="w-14 h-px bg-gold mx-auto mb-6" />
        <p className="text-center text-cream/50 text-sm italic max-w-2xl mx-auto mb-14">
          Цены указаны за экскурсию для группы до 6 человек. Для групп большего
          размера — индивидуальный расчёт.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {tours.map((tour, i) => {
            const Icon = tour.icon;
            return (
              <div
                key={tour.title}
                className={`group relative bg-ink-800 border border-white/5 p-8 transition-all duration-500 hover:border-gold/40 hover:bg-ink-700 reveal reveal-delay-${(i % 4) + 1} ${isVisible ? 'is-visible' : ''}`}
              >
                {/* Top accent */}
                <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                <div className="flex items-start gap-4 mb-4">
                  <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center border border-gold/30 text-gold rounded-sm transition-all duration-500 group-hover:border-gold group-hover:bg-gold/10">
                    <Icon size={20} strokeWidth={1.5} />
                  </div>
                  <h3 className="font-serif text-xl text-cream font-semibold pt-2 group-hover:text-gold-bright transition-colors duration-300">
                    {tour.title}
                  </h3>
                </div>

                <p className="text-sm text-cream/60 leading-relaxed mb-6">
                  {tour.text}
                </p>

                <div className="flex items-center justify-between pt-5 border-t border-white/5">
                  <span className="text-xs text-cream/40 uppercase tracking-wider">
                    {tour.duration}
                  </span>
                  <span className="font-serif text-2xl text-gold-bright font-semibold">
                    {tour.price}
                  </span>
                </div>
              </div>
            );
          })}

          {/* Note card fills the last grid cell */}
          <div className="flex flex-col items-center justify-center p-8 border border-dashed border-white/10 text-center">
            <p className="text-cream/40 text-sm italic mb-6">
              Стоимость входных билетов в музеи и на объекты оплачивается отдельно.
            </p>
            <a
              href="#contacts"
              className="px-6 py-3 border-2 border-gold text-gold-bright font-semibold text-sm tracking-wide rounded-sm hover:bg-gold hover:text-ink-900 transition-all duration-300"
            >
              Обсудить индивидуальный маршрут
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
